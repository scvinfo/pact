package com.pact.demo.service;

import com.pact.demo.dto.Item;
import org.springframework.stereotype.Service;

@Service
public class RetailerService {

    public Item getItemDetails(String itemId) {
        return new Item("Apple", "iPhone", 1000.0);
    }
}