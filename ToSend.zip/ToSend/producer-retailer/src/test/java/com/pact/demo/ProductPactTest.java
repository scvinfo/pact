package com.pact.demo;

public class ProductPactTest {
}
